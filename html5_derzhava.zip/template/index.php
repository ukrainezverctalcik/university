<?php defined('_JEXEC') or die; ?>
<!DOCTYPE html>
<html lang="uk">
<head>
  <jdoc:include type="head" />
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header>
    <h1>Моя Держава</h1>
    <p>Інформаційний портал про країну, владу, закони, культуру та новини</p>
  </header>

  <nav>
    <jdoc:include type="modules" name="menu" style="none" />
  </nav>

  <main>
    <jdoc:include type="component" />
  </main>

  <footer>
    <p>&copy; 2024 Моя Держава. Всі права захищено.</p>
  </footer>
</body>
</html>
